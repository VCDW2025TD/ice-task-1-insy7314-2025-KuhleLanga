import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout/Layout';
import Register from './components/Register/Register';
import Login from './components/Login/Login';
import Dashboard from './components/Dashboard/Dashboard';
import Logout from './components/Logout/Logout';
import ProtectedRoute from './components/ProtectedRoute/ProtectedRoute';
import SecurityDemo from './components/SecurityDemo/SecurityDemo';
import './App.css';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          {/* Public home page - redirects to dashboard if logged in */}
          <Route path="/" element={
            localStorage.getItem('token') 
              ? <Navigate to="/dashboard" replace /> 
              : <div className="welcome-container">
                  <h1>Welcome to SecureBlog</h1>
                  <p>Please login or register to continue.</p>
                </div>
          } />

          {/* Authentication routes */}
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/logout" element={<Logout />} />

          {/* Protected routes */}
          <Route path="/dashboard" element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          } />

          {/* Security Demo route */}
          <Route path="/security-demo" element={<SecurityDemo />} />

          {/* Catch-all route for 404s */}
          <Route path="*" element={
            <div className="not-found">
              <h1>404 - Page Not Found</h1>
              <p>The page you are looking for doesn't exist.</p>
            </div>
          } />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;
