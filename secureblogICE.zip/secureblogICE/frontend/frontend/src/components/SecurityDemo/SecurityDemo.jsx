import { useState } from "react";

export default function SecurityDemo() {
  const [events, setEvents] = useState([]);

  const log = (msg) => setEvents((prev) => [...prev, msg]);

  const tryExternalFetch = async () => {
    try {
      // INTENTIONAL VIOLATION: connect to another origin (blocked by connect-src 'self')
      const res = await fetch("https://api.github.com/rate_limit");
      log(`External fetch status: ${res.status}`);
    } catch (e) {
      log(`External fetch error: ${e}`);
    }
  };

  const tryEval = () => {
    try {
      // INTENTIONAL VIOLATION: dynamic code execution (blocked: no 'unsafe-eval')
      const fn = new Function("return 42");
      alert(fn());
    } catch (e) {
      log(`Eval error: ${e}`);
    }
  };

  return (
    <div style={{ padding: 16 }}>
      <h2>CSP Violation Demo</h2>

      {/* INTENTIONAL VIOLATION: external image (blocked by img-src 'self') */}
      <img
        src="https://images.unsplash.com/photo-1549880338-65ddcdfd017b"
        alt="Should be blocked by CSP"
        width={300}
        height={200}
        onError={() => log("External image blocked (expected)")}
      />

      <div style={{ marginTop: 12 }}>
        <button onClick={tryExternalFetch}>Test External Fetch</button>
        <button onClick={tryEval} style={{ marginLeft: 8 }}>
          Test eval() Function
        </button>
      </div>

      <h3 style={{ marginTop: 16 }}>CSP Violation Events:</h3>
      <ul>
        {events.map((e, i) => (
          <li key={i}>{e}</li>
        ))}
      </ul>

      <div style={{ marginTop: 20, padding: 10, backgroundColor: '#f5f5f5', borderRadius: 4 }}>
        <p>
          <strong>Instructions:</strong>
        </p>
        <ul>
          <li>Open DevTools → Console & Network tabs to observe CSP blocks</li>
          <li>Check backend logs for POSTs to <code>/csp-report</code></li>
          <li>Each button above will trigger different CSP violations</li>
          <li>The image above should be blocked by CSP img-src policy</li>
        </ul>
      </div>
    </div>
  );
}
