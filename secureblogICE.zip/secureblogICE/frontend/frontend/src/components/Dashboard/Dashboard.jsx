import { useState, useEffect } from 'react';
import API from '../../services/api';
import './Dashboard.css';

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [userEmail, setUserEmail] = useState('');

  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const response = await API.get('/auth/profile');
        setUserEmail(response.data.email);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching profile:', error);
        setError('Failed to load user profile');
        setLoading(false);
      }
    };

    fetchUserProfile();
  }, []);

  if (loading) {
    return (
      <div className="dashboard-container">
        <p>Loading...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="dashboard-container">
        <div className="error-message">{error}</div>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      <h1>Welcome to Your Dashboard</h1>
      <div className="dashboard-content">
        <div className="user-info">
          <h2>Profile Information</h2>
          <p>Email: {userEmail}</p>
        </div>
        <div className="dashboard-stats">
          <h2>Account Status</h2>
          <p>✓ Authenticated</p>
          <p>✓ Profile Active</p>
        </div>
      </div>
    </div>
  );
}
