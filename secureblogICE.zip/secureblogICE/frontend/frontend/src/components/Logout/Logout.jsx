import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Logout() {
  const navigate = useNavigate();

  useEffect(() => {
    // Clear the authentication token
    localStorage.removeItem('token');
    
    // Redirect to home page
    navigate('/', { 
      state: { message: 'You have been successfully logged out' },
      replace: true 
    });
  }, [navigate]);

  // Return null since this component doesn't render anything
  return null;
}
