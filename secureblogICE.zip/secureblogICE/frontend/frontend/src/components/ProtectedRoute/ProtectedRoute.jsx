import { Navigate } from 'react-router-dom';

export default function ProtectedRoute({ children }) {
  const isAuthenticated = () => {
    const token = localStorage.getItem('token');
    return !!token;
  };

  if (!isAuthenticated()) {
    // Redirect to login page with a message
    return <Navigate to="/login" state={{ message: 'You must log in first' }} replace />;
  }

  return children;
}
